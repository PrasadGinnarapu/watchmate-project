from django.contrib import admin
from watchlist_app.models import Movie

# Register your models here.
admin.site.register(Movie)

